package com.example.filehandlingapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    Button saveBtn, loadBtn;
    EditText editText;
    TextView displayText;
    private final String fileName = "mydata.txt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize Views
        saveBtn = findViewById(R.id.button);
        loadBtn = findViewById(R.id.button2);
        editText = findViewById(R.id.editText);
        displayText = findViewById(R.id.textview2);

        // Save Button
        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String data = editText.getText().toString();
                if (data.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter some data", Toast.LENGTH_SHORT).show();
                    return;
                }
                try {
                    FileOutputStream fos = openFileOutput(fileName, MODE_APPEND);
                    fos.write((data + "\n").getBytes());
                    fos.close();
                    Toast.makeText(MainActivity.this, "File saved", Toast.LENGTH_SHORT).show();
                    editText.setText(""); // clear input
                } catch (IOException e) {
                    e.printStackTrace();
                    Toast.makeText(MainActivity.this, "Error saving file", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Load Button
        loadBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    FileInputStream fis = openFileInput(fileName);
                    int c;
                    StringBuilder temp = new StringBuilder();
                    while ((c = fis.read()) != -1) {
                        temp.append((char)c);
                    }
                    fis.close();
                    displayText.setText(temp.toString());
                    Toast.makeText(MainActivity.this, "File loaded", Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    e.printStackTrace();
                    Toast.makeText(MainActivity.this, "Error reading file", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}