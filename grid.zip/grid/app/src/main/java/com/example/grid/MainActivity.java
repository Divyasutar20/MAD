package com.example.grid;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button btnRating, btnMyApp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnRating = findViewById(R.id.btnRating);
//        btnMyApp = findViewById(R.id.btnMyApp);

        btnRating.setOnClickListener(v -> {
            // CHANGE this to your actual RatingBar activity name
            Intent intent = new Intent(MainActivity.this,RatingActivity.class);
            startActivity(intent);
        });

//        btnMyApp.setOnClickListener(v -> {
//            // CHANGE this to your actual MyApplication activity name
//            Intent intent = new Intent(MainActivity.this, MyApplicationActivity.class);
//            startActivity(intent);
//        });
    }
}